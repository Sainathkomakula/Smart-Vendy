var express = require('express');
var app = express();
var http = require('http').Server(app);
var path    = require("path");
var io = require('socket.io')(http);
var io_https = require('socket.io')(https);

var https = require('https');
var fs = require('fs');


var debug = require('debug')('rest-server:server');
var request = require('request');
var port = 3000;
var Secport = 3443;
var request = require('request');
var Authorization_code;// Authorization code after Login with Amazon
var access_token_DRS;// Access token for DRS API & other API call in DRS category
var refresh_token_DRS;// REfre tokem if access token expires
//var slotID = 'bf3f0b71-7851-4b8c-9c6c-7364118d130f';
var serialPort = require('serialport');
var SerialPort = serialPort.SerialPort;
var Last_purchase_time;// Last trasaction time
var remainingQuantity_KitKat;// Variable to check remaining quantity of KitKat
var remainingQuantity_Oreo;// Variable to check remaining quantity of Oreo
var originalQuantity;// original Quantity
var KitKat;// Kit amount
var Oreo;//oreo amount


var Slot_status_import = require('./slot_status.js'); // importing slot_status.js file
var DRS_call_import = require('./DRS_call.js');// importing DRS_call.js file
var Subscription_import = require('./Suscribe_info.js');// importing Suscribe_info.js file
var DeviceStatus_import = require('./Device_status.js');// importing Device_status.js file
var Deregister_import = require('./Deregistration.js');// importing Deregistration.js file

//Configuring Serial port with MCU
var portName = '/dev/ttyS0';
serialPort = new SerialPort(portName, {
    baudrate: 57600,
    // def  aults for Arduino serial communication
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false
});
app.use(express.static(__dirname + '/public'));
app.use(express.static(path.join(__dirname, '/public')))

//loading initial page
app.get('/', function(req, res) {
    res.sendfile('LWA.html');
});
app.get('/contents_new', function(req, res) {
    res.sendFile(path.join(__dirname + '/contents_new.html'));
});

app.get('/Topup_RFID', function(req, res) {
    res.sendFile(path.join(__dirname + '/Topup_RFID.html'));
});


//Handling Socket io connection of http
io.on('connection', function(socket) {

    console.log('new client connected');

    //Socket event for input count of quantity at the time of refillment if user enter before login
    socket.on('KitKatQuantityEvent', function(data){
 console.log("Number of KitKat quantity"+ data);
 KitKat=data;
 remainingQuantity_KitKat=KitKat;
 serialPort.write(data+'&');// & used to differentiate KitKat  and Oreo va;ue on MCU via serial communicarion along with Kitkat amount
 //      serialPort.write("&");

        });

 socket.on('OreoQuatityEvent', function(data){
              console.log("Number of Oreo quantity"+ data);
Oreo=data;
remainingQuantity_Oreo=Oreo;
 serialPort.write(data);

            });
            socket.on('TopupEvent', function(data){
       console.log("Amount Topuped  ="+ data);
         serialPort.write(data); // Serial writing Oreo quantity
                });
    /*    socket.on('OreoQuatityEvent', function(data){
              console.log("Number of Oreo quantity ="+ data);
       serialPort.write(data);
     });*/



});

//Initializing http server
http.listen(port, function() {
    console.log('listening on *:3000');
});


//Options for creating HTTPS server and reading file of PRIVATE  KEY and CERTIFICATE
var options = {

    key: fs.readFileSync(__dirname + '/25827299-localhost_3000.key'),// importing key for secure server
    cert: fs.readFileSync(__dirname + '/25827299-localhost_3000.cert')//importing CERTIFICATE for secure server
};


//creating secure server
var secureServer = https.createServer(options, app)

//Initializing secure Socket IO events
var io_sec = require('socket.io')(secureServer);
//Initializing secure server
secureServer.listen(Secport, function() {
    console.log('Server listening on port ', Secport);

});

//Handling  secure Socket IO events
io_sec.on('connection', function(socket) {
    console.log('new secure client connected');

    //Socket event for input count of quantity at the time of refillment


    //Authorization code socket event generted from HTML page
    socket.on('Auth_code', function(data) {
        console.log(data);
        Authorization_code = data;



        access_token_function();  // calling access token function to get access_token
    });


    //Subscription_event
    socket.on('Subscription_event', function(data) {
        console.log(data);

        //Subscr_function call in Suscribe_info module
        Subscription_import.Subscr_function(access_token_DRS); //


    });

    //Socket of event DeviceStatus_event
    socket.on('DeviceStatus_event', function(data) {
        console.log(data);

        //deviceStatus_function call in Device_status.js module
        DeviceStatus_import.deviceStatus_function(access_token_DRS);


    });

    //Socket of event SlotStatus_event
    socket.on('SlotStatus_event', function(data) {
        console.log(data);

        //Slot_Status_function call in SlotStatus.js with Last purchase time parameter
        Slot_status_import.Slot_Status_function(access_token_DRS, Last_purchase_time ,remainingQuantity,originalQuantity);


    });
    socket.on('Deregister_device_event', function(data) {
        console.log(data);

        //Slot_Status_function call in SlotStatus.js
        Deregister_import.deregistration_function(access_token_DRS);


    });


});

//Access Token function
function access_token_function() {
    console.log("Calling Access Token Function");
    var headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    // Configure the request
    var options = {
        url: 'https://api.amazon.com/auth/o2/token',
        port: 443,
        method: 'POST',
        headers: headers,
        form: {
            'grant_type': 'authorization_code',
            'code': Authorization_code,
            'client_id': 'amzn1.application-oa2-client.ad6e919aadf242b88ee0951a7e5a9399', // client ID of manufacturer/whole saler who supplies prducts to vendor
            'client_secret': '4030d7b62041b4a0cb887c5d9d013f11824dea8a3e241cb43e869c1e0bfea7bd', // client secret of manufacturer/whole saler who supplies prducts to vendor
            'redirect_uri': 'https://192.168.1.133:3443' // redirect URL of vending machine server i.e MediaTEk 7688 duo
        }
    }

    // Start the request for access token
    request(options, function(error, response, body) {
        console.log('statusCode:', response.statusCode);
        console.log('headers:', response.headers);
        if (!error && response.statusCode == 200) {
            // Print out the response body
            console.log(body);

            var Extract_access_token = JSON.parse(body);
            access_token_DRS = Extract_access_token.access_token;
            refresh_token_DRS = Extract_access_token.refresh_token;
            console.log('\n');
            console.log("Access token = " + access_token_DRS);
            console.log('\n');
            console.log("Refresh token = " + refresh_token_DRS);
            //    time_check_access_token_1 = new Date();

        }
    })


}


// Refresh Token fuction  Before placing order
function refresh_token_function() {
    var headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    // Configure the request
    var options = {
        url: 'https://api.amazon.com/auth/o2/token',
        port: 443,
        method: 'POST',
        headers: headers,
        form: {
            'grant_type': 'refresh_token',
            'refresh_token': refresh_token_DRS,
            'client_id': 'amzn1.application-oa2-client.ad6e919aadf242b88ee0951a7e5a9399',// client ID of manufacturer/whole saler who supplies prducts to vendor
            'client_secret': '4030d7b62041b4a0cb887c5d9d013f11824dea8a3e241cb43e869c1e0bfea7bd', // client secret of manufacturer/whole saler who supplies prducts to vendor
            'redirect_uri': 'https://192.168.1.133:3443'// redirect URL of vending machine server i.e MediaTEk 7688 duo
        }
    }

    // Start the request for refresh_token
    request(options, function(error, response, body) {
        console.log('statusCode:', response.statusCode);
        console.log('headers:', response.headers);
        if (!error && response.statusCode == 200) {
            // Print out the response body
            console.log(body);
            var Extract_access_token = JSON.parse(body);

            //assgning acess token & refresh token  value to  respective variable
            access_token_DRS = Extract_access_token.access_token;
            refresh_token_DRS = Extract_access_token.refresh_token;
            console.log('\n');
            console.log("Access token = " + access_token_DRS);
            console.log('\n');
            console.log("Refresh token = " + refresh_token_DRS);
        }
    })
}




//listening Serial Port from MCU ATMega32U4
serialPort.on('data', function(data) {
console.log('Hi');
Last_purchase_time = new Date();
if(data=="KitKat")
{
  var slot_number_1=1;
  var slot_number_2=2;
  remainingQuantity_KitKat = remainingQuantity_KitKat - 1;// Decreasing value of respective slot quanity by 1
  console.log("Remaining Quantity of KitKat =" + remainingQuantity_KitKat)
}
else if((data=="Oreo"))
remainingQuantity_Oreo = remainingQuantity_Oreo - 1;// Decreasing value of respective slot quanity by 1
console.log("Remaining Quantity of Oreo =" + remainingQuantity_Oreo);

// checking threshold level of quantity , so that it  can order before it get out of stock
if (remainingQuantity_KitKat == "2") {
    console.log('\n');
    console.log("Oreo  are running out of stock");
    console.log('\n');
    console.log("Ordering using Amazon DRS")
    console.log('\n');


    refresh_token_function();//Calling refresh_token_function before placing order to avoid issue with access_token expire


    setTimeout(DRS_call_import.DRS_call_function(access_token_DRS,slot_number_1),3000); // calling DRS_call_function by passing slot number to order

}

// checking threshold level of quantity , so that it  can order before it get out of stock
else if (remainingQuantity_Oreo=="2") {
  console.log('\n');
  console.log("KitKat  are running out of stock");
  console.log('\n');
  console.log("Ordering using Amazon DRS")
  console.log('\n');

  //Calling refresh_token_function before placing order to avoid issue with access_token expire
  refresh_token_function();
  DRS_call_import.DRS_call_function(access_token_DRS,slot_number_2);// calling DRS_call_function by passing slot number to order

    }



});
